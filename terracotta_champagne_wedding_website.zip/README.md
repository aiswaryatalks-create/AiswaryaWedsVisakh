# Wedding Invitation Website

A mobile-friendly, single-page wedding invitation website with a warm **Terracotta & Champagne** palette, Parisienne script typography, an animated envelope, photo placeholders, story timeline, lyric interludes, ceremony/reception details, QR codes, countdown, heart-marked calendar, music control, and closing message.

## Before publishing
Open `index.html` in a text editor and update the `SETTINGS` object near the bottom:
- Bride and groom names
- Wedding date and displayed date text
- Ceremony and reception venue names, dates, addresses and Google Maps links
- Closing message
- Photo URLs and song lyric excerpts in the page markup
- Optional background music URL
- Optional RSVP endpoint if you decide to add a connected form

The QR codes are generated from the Google Maps URLs entered in `SETTINGS`. Replace sample image URLs with your own photos before sharing publicly.

## Publish on Render
1. Upload the contents of this folder to a GitHub repository (make sure `index.html` is at the repository root).
2. In Render, create a **Static Site** and connect that repository.
3. Set the build command to blank and the publish directory to `.`.
4. Deploy. Render will provide a public URL.

This is a starter template; placeholder names, dates, locations and photographs must be replaced before the invitation is final.
